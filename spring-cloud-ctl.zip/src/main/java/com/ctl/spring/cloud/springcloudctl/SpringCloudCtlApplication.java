package com.ctl.spring.cloud.springcloudctl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudCtlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudCtlApplication.class, args);
	}

}

