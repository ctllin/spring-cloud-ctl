package com.ctl.spring.cloud.springcloudctl.service;

/**
 * <p>Title: GreetingController</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2018</p>
 * <p>Company: www.hanshow.com</p>
 *
 * @author guolin
 * @version 1.0
 * @date 2018-12-17 13:52
 */
public interface GreetingController {
     String greeting();
}
